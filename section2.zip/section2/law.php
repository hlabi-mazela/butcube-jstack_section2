<?php
  include 'inc/connection.php';
  session_start();
  if (!$_SESSION['email']){
    header("location: login.php");
  }

 ?>
<!DOCTYPE HTML>
<html>
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Bachelor Of Commerce in Law</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="" />
	<meta name="keywords" content="" />
	<meta name="author" content="" />

  	<!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<!-- <link href="https://fonts.googleapis.com/css?family=Droid+Sans" rel="stylesheet"> -->

	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Themify Icons-->
	<link rel="stylesheet" href="css/themify-icons.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">

	<!-- Magnific Popup -->
	<link rel="stylesheet" href="css/magnific-popup.css">

	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">

	<!-- Theme style  -->
	<link rel="stylesheet" href="css/style.css">

	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->

	</head>
	<body>

	<div class="gtco-loader"></div>

	<div id="page">
	<nav class="gtco-nav" role="navigation">
		<div class="gtco-container">
			<div class="row">
			</div>
			<div class="row">
				<div class="col-sm-4 col-xs-12">
					<div id="gtco-logo"><a href="index.html">
						<img src="images/jstack.png" alt="Logo">
						 </a></div>
				</div>
				<div class="col-xs-8 text-right menu-1">
					<ul>
						<li class="active"><a href="index.php">Home</a></li>
						<li><a href="newlect.php">Add Lecture</a></li>
						<li><a href="about.html">All Lectures</a></li>
						<li class="has-dropdown">
							<a href="services.html">All Student</a>
							<ul class="dropdown">
								<li><a href="#">Advanced Certificate</a></li>
								<li><a href="#">Graduate Certificate</a></li>
								<li><a href="#">Postgraduation Certificate</a></li>
							</ul>
						</li>
						<li class="has-dropdown">
							<a href="#">Degrees</a>
							<ul class="dropdown">
								<li><a href="#">Masters</a></li>
								<li><a href="#">PhD</a></li>
								<li><a href="#">Law</a></li>
								<li><a href="#">Online</a></li>
							</ul>
						</li>
						<li><a href="#"><i class="ti-user">Login</i></a></li>
						<li><a href="register.php"><i class="ti-pencil-alt">Register</i></a></li>
					</ul>
				</div>
			</div>

		</div>
	</nav>

	<header id="gtco-header" class="gtco-cover" role="banner" style="background-image:url(images/6.jpg);">
		<div class="overlay"></div>
		<div class="gtco-container">
			<div class="row">
				<div class="col-md-12 col-md-offset-0 text-left">
					<div class="display-t">
						<form class="" action="" method="post">
              <div class="display-tc">
  							<h1 class="animate-box" data-animate-effect="fadeInUp">BITCUBE INTERNSHIP ADMIN</h1>
  						</div>
            </form>
					</div>
				</div>
			</div>
		</div>
	</header>

	</div>

  <div class="container">
    <div class="row">
      <h1>Bachelor Of Commerce in Law</h1>
      <p>
        Bitcube welcomes you. The duration of this field will last 3 years
      </p>
      <table class="table table-bordered">
        <tr>
          <th>Qualification Stream</th>
          <th>Qualification Code</th>
          <th>NQF level</th>
          <th>Total Credits</th>
          <th>SAQA ID</th>
          <th>APS/AS</th>
        </tr>
        <tr>
          <td>Bachelor Of Commerce in Law</td>
          <td>90123 - LAW</td>
          <td>7</td>
          <td>360</td>
          <td>101041</td>
          <td>21</td>
        </tr>
      </table>
    </div>
  </div>


  <div class="container">
    <h4><b>Curriculum for your qualification</b></h4>
    <div class="row">
        <table class="table table-bordered">
        <h5><u>FIRST LEVEL</u>(5)</h5>
        <tr>
          <th><b>Modules</b></th>
          <th>CPD1501</th>
          <th>ECS1501</th>
          <th>FAC1502</th>
          <th>FAC1502</th>
          <th>HFL1501</th>
          <th>ILW1501</th>
          <th>PVL1501</th>
          <th>SJD1501</th>
        </tr>
        <tr>
          <td class="offset"></td>
          <td>Citizenship, Public Participation</td>
          <td>Economics 1A</td>
          <td>Financial Accounting Principals, and Concepts and Procedures</td>
          <td>Historical Founcations of South Africa</td>
          <td>Intro to Law</td>
          <td>Business Management</td>
          <td>Law of Persons</td>
          <td>Social Dimensions of Justice</td>
        </tr>
      </table>


      <table class="table table-bordered">
        <h5><u>SECOND LEVEL</u>(6)</h5>
        <tr>
          <th><b>Modules</b></th>
          <th>ADL2601</th>
          <th>CRW2601</th>
          <th>MNB2601</th>
        </tr>
        <tr>
          <td class="offset"></td>
          <td>Administrative Law</td>
          <td>General Principals of Criminal Law</td>
          <td>Business Management</td>
        </tr>

      </table>

    </div>
  </div>


<div class=""style="margin-top: 100px;">

</div>

	<!-- jQuery -->
	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<!-- Carousel -->
	<script src="js/owl.carousel.min.js"></script>
	<!-- countTo -->
	<script src="js/jquery.countTo.js"></script>
	<!-- Magnific Popup -->
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/magnific-popup-options.js"></script>
	<!-- Main -->
	<script src="js/main.js"></script>

	</body>
</html>
