<?php 
	include '../inc/connection.php';
	session_start();
	
  if (!$_SESSION['email']){
    header("location: login.php"); # IF LECTURE DOESN'T HAVE A SESSION, DENY ACCESS
  }

	
	$nameErr = $lnameErr = $emailErr = $pswErr = " ";
	$name = $lname = $email = $psw = " ";

	if ($_SERVER["REQUEST_METHOD"] == "POST"){
		if (empty($_POST['name'])){
			$nameErr = "Name is required";
		}else{
			$name = test_input($_POST["name"]);
		}
		if (empty($_POST['lname'])){
			$lnameErr = "Surname is required";
		}else{
			$name = test_input($_POST["lname"]);
		}
		if (empty($_POST['email'])){
			$emailErr = "Email is required";
		}else{
			$name = test_input($_POST["email"]);
		}



	}
	function test_input($data){
		$data = trim($data);
		$data = stripcslashes($data);
		$data = htmlspecialchars($data);
		return $data;
	}
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>REGISTER NEW STUDENT</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="" />
	<meta name="keywords" content="" />
	<meta name="author" content="" />

  	<!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<!-- <link href="https://fonts.googleapis.com/css?family=Droid+Sans" rel="stylesheet"> -->

	<!-- Animate.css -->
	<link rel="stylesheet" href="../css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="../css/icomoon.css">
	<!-- Themify Icons-->
	<link rel="stylesheet" href="../css/themify-icons.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="../css/bootstrap.css">

	<!-- Magnific Popup -->
	<link rel="stylesheet" href="../css/magnific-popup.css">

	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="../css/owl.carousel.min.css">
	<link rel="stylesheet" href="../css/owl.theme.default.min.css">

	<!-- Theme style  -->
	<link rel="stylesheet" href="../css/style.css">

	<!-- Modernizr JS -->
	<script src="../js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->


	<style type="text/css">
		.error{
			color: red;
			font-size: 16px;
			font-weight: 700;

		}
		h3{
			text-align: center;
			text-transform: uppercase;
			font-size: 3vw;
			font-family: "Poppins", Sans-serif;
			color: #c1c1c1;
		}
	</style>
</head>
<body>


	<nav class="gtco-nav" role="navigation">
		<div class="gtco-container">
			<div class="row">
			</div>
			<div class="row">
				<div class="col-sm-4 col-xs-12">
					<div id="gtco-logo"><a href="index.html">
						<img src="../images/jstack.png" alt="Logo">
						 </a></div>
				</div>
				<div class="col-xs-8 text-right menu-1">
					<ul>
						<li><a href="index.php" style="color: #000">Home</a></li>
						<li><a href="mystd.php" style="color: #000">My Students</a></li>
						<li><a href="addstd.php" style="color: #000">Add Student</a></li>
						<li><a href="changepsw.php" style="color: #000">Change Password</a></li>
						<li><a href="logout.php" style="color: #000"><i class="ti-pencil-alt">Logout</i></a></li>
					</ul>
				</div>
			</div>

		</div>
	</nav>




	<div class="gtco-section">
		<div class="gtco-container">
			<div class="row row-pb-md">
				<div class="col-md-12 animate-box">
					<h3>Register Student</h3>
					<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">
				


				<div class="form-group">
					<input type="text" value="<?php if (isset($_POST['name'])){ echo $name; } ?>" name="name" class="form-control" placeholder="Learner Name"><br>
					<span class="error"><?php echo $nameErr; ?></span>
				</div>
				<br>
				<div class="form-group">
					<input type="text" name="lname" value="<?php if (isset($_POST['lname'])){ echo $lname; } ?>" class="form-control" placeholder="Learner Surname"><br>
					<span class="error"><?php echo $lnameErr; ?></span>
				</div>
				<br>
				<div class="form-group">
					<input type="email" name="email" value="<?php if (isset($_POST['email'])){ echo $email; } ?>" class="form-control" placeholder="Learner Email"><br>
					<span class="error"><?php echo $emailErr; ?></span>
				</div>
				<br>
				<div class="form-group">
					<input type="date" name="dob" class="form-control" placeholder="Learner Date Of Birth">
				</div>
				<br>
				<div class="row form-group">
            		<select name="degree" id="" class="form-control">
              			<option value="" disabled="">Please choose a Degree</option>
              			<!--
							Get all the degrees from database and list them.
						 -->
							<?php
								$sql = $db->query("SELECT degree_name FROM degree");
								while ($row = mysqli_fetch_assoc($sql)){
									echo "<option value='".$row['degree_name']."'>".$row['degree_name']."</option>";
								}
							 ?>
            		</select>
          		</div>
          		<br>

				<div class="form-group">
					<input type="password" class="form-control" name="psw" placeholder="Learner password"><br>
					<span class="error"><?php echo $pswErr; ?></span>
				</div>
				<div class="form-group">
					<p align="center">
						<input type="submit" name="register" value="Register" class="btn btn-primary btn-lg">
					</p>
				</div>

					</form>
			</div>
		</div>
	</div>
</div>






















<!-- jQuery -->
	<script src="../js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="../js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="../js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="../js/jquery.waypoints.min.js"></script>
	<!-- Carousel -->
	<script src="../js/owl.carousel.min.js"></script>
	<!-- countTo -->
	<script src="../js/jquery.countTo.js"></script>
	<!-- Magnific Popup -->
	<script src="../js/jquery.magnific-popup.min.js"></script>
	<script src="../js/magnific-popup-options.js"></script>
	<!-- Main -->
	<script src="../js/main.js"></script>

</body>
</html>