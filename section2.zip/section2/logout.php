<?php
  include 'inc/connection.php'; // GET CONNECTION
  session_start(); // START A SESSION
  session_destroy(); // DESTROY SESSION
  header("location: index.php"); // REDIRECT

 ?>
