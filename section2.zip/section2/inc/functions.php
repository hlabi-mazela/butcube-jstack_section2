<?php
  include 'connection.php'; // GET CONNECTION
  session_start(); // START SESSION
  ob_start();

  if (isset($_POST['register'])){
    // GET USER INPUT AND IF IT IS VALID, CAPTURE AND INSERT INTO DATABASE
    $name = $_POST['name'];
    $lName = $_POST['lName'];
    $email = $_POST['email'];
    $dob = $_POST['dob'];
    $degree = $_POST['degree'];
    $psw = $_POST['psw'];
    $status = "hlabi";

    $cpsw = $_POST['cpsw'];

    // CHECK IF USER HAS AN ACCOUNT
    $check = $db->query("SELECT email FROM student WHERE email LIKE '$email'");
    $check_student = mysqli_num_rows($check);

    if ($check_student >= "1"){
      echo "<script>alert('You already have a registered account')</script>";
      echo "<script>window.open('../register.php','_self')</script>";
    }else{
      // GET USER IP address
      $user_ip = getUserIP();
      $degree = getDegree();
      // INSERT INTO DATABASE
      $sql = $db->query("INSERT INTO student(user_ip,names,lname,email,dob,qulification,pass,status)
       VALUES('$user_ip','$name','$lName','$email','$dob','".$_POST['degree']."','".md5($_POST['psw'])."','$status')");
       if ($sql){
         echo "<script>alert('Registration was successful')</script>";
         echo "<script>window.open('../login.php','_self')</script>";
       }else{
         echo "<script>alert('Error logging in. Please reload the page and try again')</script>";
         echo "<script>window.open('../register.php','_self')</script>";
       }
 

    }



  }

  if (isset($_POST['admin_register'])){
    // GET USER INPUT AND IF IT IS VALID, CAPTURE AND INSERT INTO DATABASE
    $name = $_POST['name'];
    $lName = $_POST['lName'];
    $email = $_POST['email'];
    $pnum = $_POST['pnum'];
    $degree = $_POST['degree'];
    $dob = $_POST['dob'];
    $psw = $_POST['psw'];
    $status = "hlabi";

    $cpsw = $_POST['cpsw'];

    // CHECK IF USER HAS AN ACCOUNT
    $check = $db->query("SELECT l_email FROM lecture WHERE l_email LIKE '$email'");
    $check_student = mysqli_num_rows($check);

    if ($check_student >= "1"){
      echo "<script>alert('You already have a registered account')</script>";
      echo "<script>window.open('../register.php','_self')</script>";
    }else{
      // GET USER IP address
      $user_ip = getUserIP();
      $degree = getDegree();
      // INSERT INTO DATABASE
      $sql = $db->query("INSERT INTO lecture(l_names,l_lname,l_email,pnum,gender,course_responsible,dob,psw,status)
       VALUES('$name','$lName','$email','".$_POST['pnum']."','".$_POST['gender']."','".stripslashes($_POST['degree'])."','$dob',
       '".md5($_POST['psw'])."','$status')");
       if ($sql){
         echo "<script>alert('Lecture registration was successful')</script>";
         echo "<script>window.open('../admin/newlect.php','_self')</script>";
       }else{
         echo "<script>alert('Error registering lecture.')</script>";
         echo "<script>window.open('../admin/newlect.php','_self')</script>";
         echo mysqli_error($db);
       }


    }



  }

  function getUserIP(){
    // Get visitor IP address behind CloudFlare network
    if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])){
      $_SERVER['REMOTE_ADDR'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
      $_SERVER['HTTP_CLIENT_IP'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
    }
    $client = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote = $_SERVER['REMOTE_ADDR'];

    if (filter_var($client, FILTER_VALIDATE_IP)){
      $ip = $client;
    }else if(filter_var($forward, FILTER_VALIDATE_IP)){
      $ip = $forward;
    }else{
      $ip = $remote;
    }
    return $ip;
  }



  // STUDENT LOGIN
  if (isset($_POST['login'])){
    // SANITIZE USERINPUT
    $email = mysqli_real_escape_string($db, $_POST['email']);
    $pass = mysqli_real_escape_string($db, $_POST['psw']);
    $psw = md5($pass); # Decrypt passward

    $sql = $db->query("SELECT * FROM student WHERE email LIKE '$email' AND pass LIKE '$psw' AND status='hlabi'");
    $check_user = mysqli_num_rows($sql);
    $row = mysqli_fetch_assoc($sql);

    if ($check_user >= "1"){
      $_SESSION['email'] = $email;
      echo "<script>alert('You have successfully logged in.')</script>";
      echo "<script>window.open('../index.php','_self')</script>";
    }else{
      echo "<script>alert('Incorrect credentials. Please try again')</script>";
      echo "<script>window.open('../admin/login.php','_self')</script>";
    }


  }



  if (isset($_POST['admin_login'])){
    $email = mysqli_real_escape_string($db, $_POST['admin_email']);
    $psw = mysqli_real_escape_string($db, $_POST['admin_psw']);
    $pass = md5($psw);
    $sql = $db->query("SELECT * FROM admin WHERE admin_email LIKE '$email' AND admin_pass LIKE '$pass' AND status='hlabi'");
    $check_user = mysqli_num_rows($sql);
    $row = mysqli_fetch_assoc($sql);

    if ($check_user >= "1"){
      $_SESSION['email'] = $email;
      $name = $row['admin_name'];
      echo "<script>alert('You have successfully logged in.')</script>";
      echo "<script>window.open('../admin/index.php','_self')</script>";
    }else{
      echo "<script>alert('Incorrect credentials. Please try again')</script>";
      echo "<script>window.open('../admin/login.php','_self')</script>";
    }


  }


  if (isset($_POST['lect_login'])){
    $email = mysqli_real_escape_string($db, $_POST['lect_email']);
    $psw = mysqli_real_escape_string($db, $_POST['lect_psw']);
    $pass = md5($psw);
    $sql = $db->query("SELECT * FROM lecture WHERE l_email LIKE '$email'
      AND psw LIKE '$pass' AND status='hlabi'");
    $check_user = mysqli_num_rows($sql);
    $row = mysqli_fetch_assoc($sql);

    if ($check_user >= "1"){
      $_SESSION['email'] = $email;
      $name = $row['l_names'];
      echo "<script>alert('You have successfully logged in.')</script>";
      echo "<script>window.open('../lectures/index.php','_self')</script>";
    }else{
      echo "<script>alert('Incorrect credentials. Please try again')</script>";
      echo "<script>window.open('../lectures/login.php','_self')</script>";
      echo mysqli_error($db);
    }


  }



  function getDegree(){
    $study = "";
    switch ($_POST['degree']){
      case 1:
      $study = "Bachelor of Business Administration - 4 Years";
      echo "Years of studying is 4 years";
      break;

      case 2:
      $study = "Bachelor of Commerce in Accounting- 5 Years";
      echo "Years of studying is 5 years";
      break;

      case 3:
      $study = "Bachelor of Commerce in Law- 6 Years";
      echo "Years of study 6 years";
      break;

      case 4:
      $study = "Bachelor of Commerce- 7 Years";
      echo "Years of study 7 years.";
      break;

      case 5:
      $study = "Bachelor of Science in Information Technology- 6 Years";
      echo "Years of study 6 years";
      break;

      case 6:
      $study = "Higher Certificate in Business Management- 5 Years";
      echo "Years of study 5 years";
      break;

      case 7:
      $study = "Master Degrees- 4 Years";
      echo "Years of study 4 years";
      break;

      case 8:
      $study = "Doctoral Degrees- 3 Years";
      echo "Years of study 3 years";
      break;

      case 9:
      $study = "Professional Degrees- 2 Years";
      echo "Years of study 2 years";
      break;

      case 10:
      $study = "Specialist Degrees- 3 Years";
      echo "Years of study 3 years";
      break;

      default:
      $study = "Student didnt pick any field";
      // echo "";



    }




  }

















 ?>
