<?php
  include '../inc/connection.php';
  session_start();
  if (!$_SESSION['email']){
    header("location: login.php");
  }

 ?>
<!DOCTYPE HTML>
<html>
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Bitcube Internship Programme</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="" />
	<meta name="keywords" content="" />
	<meta name="author" content="" />

  	<!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<!-- <link href="https://fonts.googleapis.com/css?family=Droid+Sans" rel="stylesheet"> -->

	<!-- Animate.css -->
	<link rel="stylesheet" href="../css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="../css/icomoon.css">
	<!-- Themify Icons-->
	<link rel="stylesheet" href="../css/themify-icons.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="../css/bootstrap.css">

	<!-- Magnific Popup -->
	<link rel="stylesheet" href="../css/magnific-popup.css">

	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="../css/owl.carousel.min.css">
	<link rel="stylesheet" href="../css/owl.theme.default.min.css">

	<!-- Theme style  -->
	<link rel="stylesheet" href="../css/style.css">

	<!-- Modernizr JS -->
	<script src="../js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->

	</head>
	<body>

	<div class="gtco-loader"></div>

	<div id="page">
	<nav class="gtco-nav" role="navigation">
		<div class="gtco-container">
			<div class="row">
			</div>
			<div class="row">
				<div class="col-sm-4 col-xs-12">
					<div id="gtco-logo"><a href="index.html">
						<img src="../images/jstack.png" alt="Logo">
						 </a></div>
				</div>
				<div class="col-xs-8 text-right menu-1">
					<ul>
						<li class="active"><a href="index.php">Home</a></li>
						<li><a href="newlect.php" style="color:#000;">Add Lecture</a></li>
						<li><a href="about.html" style="color:#000;">All Lectures</a></li>
						<li class="has-dropdown">
							<a href="services.html" style="color:#000;">All Student</a>
							<ul class="dropdown">
								<li><a href="#">Advanced Certificate</a></li>
								<li><a href="#">Graduate Certificate</a></li>
								<li><a href="#">Postgraduation Certificate</a></li>
							</ul>
						</li>
						<li class="has-dropdown">
							<a href="#" style="color:#000;">Degrees</a>
							<ul class="dropdown">
								<li><a href="#">Masters</a></li>
								<li><a href="#">PhD</a></li>
								<li><a href="#">Law</a></li>
								<li><a href="#">Online</a></li>
							</ul>
						</li>
						<li><a href=""><i class="ti-user" style="color:#000;">Login</i></a></li>
						<li><a href="logout.php" style="color:#000;"><i class="ti-pencil-alt">Logout</i></a></li>
					</ul>
				</div>
			</div>

		</div>
	</nav>

  <div class="" style="margin-top:100px;">

  </div>
  <div class="container">
    <div class="row">
      <table class="table table-hover">
        <tr>
          <th></th>
          <th>Lecture Name</th>
          <th>Lecture Surname</th>
          <th>Lecture Email</th>
          <th>Lecture Phone Number</th>
          <th>Gender</th>
          <th>Degree</th>
          <th>Date Of Birth</th>
          <th>Date Registered</th>
          <th>Action</th>
        </tr>
        <?php
          $sql = $db->query("SELECT * FROM lecture"); # DISPLAY ALL REGISTERED LECTURES
          while ($row = mysqli_fetch_assoc($sql)):
         ?>
        <tr>
          <td><?php echo $row['id']; ?></td>
          <td><?php echo $row['l_names']; ?></td>
          <td><?php echo $row['l_lname']; ?></td>
          <td><?php echo $row['l_email']; ?></td>
          <td><?php echo $row['pnum']; ?></td>
          <td><?php echo $row['gender']; ?></td>
          <td><?php echo $row['course_responsible']; ?></td>
          <td><?php echo $row['dob']; ?></td>
          <td><?php echo $row['date_insert']; ?></td>
          <!-- DELETE LECTURE -->
          <td><a href="<?php echo "delete.php?id=".$row['id']; ?>"><i class="ti-trash"></i></a></td>
          <!-- UPDATE LECTURE INFO -->
          <td><a href="<?php echo "update.php?id=".$row['id']; ?>"><i class="ti-plus"></i></a></td>
        </tr>
      <?php endwhile; ?>
      </table>

    </div>
  </div>



	</div>


	<!-- jQuery -->
	<script src="../js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="../js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="../js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="../js/jquery.waypoints.min.js"></script>
	<!-- Carousel -->
	<script src="../js/owl.carousel.min.js"></script>
	<!-- countTo -->
	<script src="../js/jquery.countTo.js"></script>
	<!-- Magnific Popup -->
	<script src="../js/jquery.magnific-popup.min.js"></script>
	<script src="../js/magnific-popup-options.js"></script>
	<!-- Main -->
	<script src="../js/main.js"></script>

	</body>
</html>
